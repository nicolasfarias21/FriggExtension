Abra o terminal do projeto dentro do vs e instale o react router v5: npm install react-router-dom@5.3.0

inicialize a api com: cd api, npm start.

inicialize o serviço react com: cd frontend, npm start.



