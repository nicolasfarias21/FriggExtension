
import React from 'react';
import Layout from '../components/Layout';
import FormGrid from '../components/FormGrid';

const RamalCrud = () => {
  return (
    <Layout>
      <FormGrid />
    </Layout>
  );
};

export default RamalCrud;
