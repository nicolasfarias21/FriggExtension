// components/menu/Menu.js
import React from "react";
import "./menu-style.css"; // Importe o estilo do menu

const Menu = () => {
  
  return (
    <body><div>
    <p>HOME</p>
</div></body>
  );
};

export default Menu;
